# occli
# DEPRECATED
Please use [gnmi](../gnmi) instead.
