// Copyright 2017 Zack Guo <zack.y.guo@gmail.com>. All rights reserved.
// Use of this source code is governed by a MIT license that can
// be found in the LICENSE file.

// +build windows

package termui

const VDASH = '|'
const HDASH = '-'
const ORIGIN = '+'
